# Level 200 - short code

A Pen created on CodePen.io. Original URL: [https://codepen.io/Alper-Demirbilek/pen/wvbGbpq](https://codepen.io/Alper-Demirbilek/pen/wvbGbpq).

